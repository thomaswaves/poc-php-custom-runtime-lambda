<?php

require __DIR__.'/vendor/autoload.php';

lambda(function ($event) {
	
	#load files
	$adjectives = file('./lambda-function/28Kadjectives.txt', FILE_IGNORE_NEW_LINES);
	$nouns = file('./lambda-function/91Knouns.txt',FILE_IGNORE_NEW_LINES);
		
	#generate random adjective
	$seed1 = rand(0,count($adjectives));
	$adjective = $adjectives[$seed1];
	#generate list of nouns with same first letter as the adjective
	$initial = $adjective[0];
	$nounsWithSameFirstLetter = array();
	for($i=0;$i<=count($nouns)-1;$i++){
		if($nouns[$i][0]===$initial){
			array_push($nounsWithSameFirstLetter,$nouns[$i]);
		}							
	}
	#generate random noun
	$seed3 = rand(0,count($nounsWithSameFirstLetter));
	$noun = $nounsWithSameFirstLetter[$seed3];
		
	#return adjective and noun
	return $adjective.' '.$noun;
	
});
